<?php

class Barang_model extends CI_model
{
    //untuk menampilkan tabel barang
    public function getBarang($id = null)
    {
        if ($id === null){
            return $this->db->get('m_barang')->result_array();
        }
        else {
            return $this->db->get_where('m_barang', ['barang_id' => $id])->result_array();
        }
    }

    //untuk hapus data barang
    public function deleteBarang($id)
    {
        $this->db->delete('m_barang', ['barang_id' => $id]);
        return $this->db->affected_rows();
    }

    //untuk membuat data barang
    public function createBarang ($data) 
    {
        $this->db->insert('m_barang', $data);
        return $this->db->affected_rows();
    }

    //untuk mengubah data barang
    public function updateBarang ($data, $id)
    {
        $this->db->update('m_barang', $data, ['barang_id' => $id]);
        return $this->db->affected_rows();
    }

     //untuk menampilkan tabel penjualan berdasarkan kode penjualan
     public function getPenjualan($id = null)
     {
         if ($id === null){
             return $this->db->select('a.*, b.barang_id, 
                                       b.penjualan_kode, b.jumlah_detail, b.total_detail, 
                                       c.barang_nama, c.barang_harga')
                            ->from('t_penjualan a')
                            ->join('t_penjualan_detail b','a.penjualan_id=b.penjualan_id')
                            ->join('m_barang c','b.barang_id=c.barang_id')
                            ->get()->result_array();
         }
         else {
             return $this->db->select('a.*, b.barang_id, 
                                       b.penjualan_kode, b.jumlah_detail, b.total_detail, 
                                       c.barang_nama, c.barang_harga')
                            ->from('t_penjualan a')
                            ->join('t_penjualan_detail b','a.penjualan_id=b.penjualan_id')
                            ->join('m_barang c','b.barang_id=c.barang_id')
                            ->where ('a.penjualan_kode', $id)
                            ->get()->result_array();
         }
     }


     //hapus data penjualan berdasarkan kode penjualan
     public function deleteDataPenjualan($id)
     {
             $this->db->delete('t_penjualan', ['penjualan_kode' => $id]);
             $this->db->delete('t_penjualan_detail', ['penjualan_kode' => $id]);
             return $this->db->affected_rows();
     }

     //menyimpan data penjualan di tabel t_penjualan
     public function createPenjualan ($data) 
    {
        $this->db->insert('t_penjualan', $data);
        return $this->db->affected_rows();
    }

    //menyimpan data penjualan di tabel t_penjualan_detail
    public function createPenjualandetail ($data) 
    {
        $this->db->insert('t_penjualan_detail', $data);
        return $this->db->affected_rows();
    }
}