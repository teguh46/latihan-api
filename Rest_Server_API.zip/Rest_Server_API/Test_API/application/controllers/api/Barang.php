<?php
// use namespace
use Restserver\Libraries\REST_Controller;

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';


class Barang extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Barang_model', 'barang');
    }

    //untuk menampilkan data barang
    public function index_get() 
    {
        $id =  $this->get('barang_id');

        if ($id === null){    
            $barang = $this->barang->getBarang();
        }
        else {
            $barang = $this->barang->getBarang($id);
        }
        
        if ($barang){
            $this->response([
            'status' => true,
            'data' => $barang]
            , REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
        }
        else {
            $this->response([
                'status' => false,
                'message' => 'No data/id not found'
            ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
        }
    }   


    //untuk menghapus data barang
    public function index_delete() 
    {
        $id = $this->delete('barang_id');

        if ($id === null){
            $this->response([
                'status' => false,
                'message' => 'Provide on id'
            ], REST_Controller::HTTP_BAD_REQUEST); // NOT_FOUND (404) being the HTTP response code
        }
        else {
            if ($this->barang->deleteBarang($id) > 0){
                //ok
                $this->response([
                    'status' => true,
                    'barang_id' => $id,
                    'message' => 'id deleted']
                    , REST_Controller::HTTP_NO_CONTENT); // NO_CONTENT (204) being the HTTP response code
            }
            else {
                //not found
                $this->response([
                    'status' => false,
                    'message' => 'id not found'
                ], REST_Controller::HTTP_BAD_REQUEST); // NOT_FOUND (404) being the HTTP response code
            }
        }
    }


    //untuk menambah data barang
    public function index_post() 
    {
        $data = [
            'barang_nama' => $this->post('barang_nama'),
            'barang_harga' => $this->post('barang_harga'),
            'barang_stok' => $this->post('barang_stok')
        ];

        if ($this->barang->createBarang($data) > 0) {
            $this->response([
                'status' => true,
                'message' => 'new barang has been created']
                , REST_Controller::HTTP_CREATED); // CREATED (201) being the HTTP response code
        }
        else {
              $this->response([
                'status' => false,
                'message' => 'fail to create new data'
            ], REST_Controller::HTTP_BAD_REQUEST); // NOT_FOUND (404) being the HTTP response code
        }
    }


    //untuk update data barang
    public function index_put() 
    {
        $id = $this->put('barang_id');
        $data = [
            'barang_nama' => $this->put('barang_nama'),
            'barang_harga' => $this->put('barang_harga'),
            'barang_stok' => $this->put('barang_stok')
        ];

        if ($this->barang->updateBarang($data, $id) > 0) {
            $this->response([
                'status' => true,
                'message' => 'data barang has been updated']
                , REST_Controller::HTTP_NO_CONTENT); // CREATED (201) being the HTTP response code
        }
        else {
              $this->response([
                'status' => false,
                'message' => 'fail to update data barang'
            ], REST_Controller::HTTP_BAD_REQUEST); // NOT_FOUND (404) being the HTTP response code
        }
    }


    //untuk menampilkan tabel penjualan berdasarkan kode penjualan
    public function penjualan_get() 
    {
        $id =  $this->get('penjualan_kode');

        if ($id === null){    
            $penjualan = $this->barang->getPenjualan();
        }
        else {
            $penjualan = $this->barang->getPenjualan($id);
        }
        
        if ($penjualan){
            $this->response([
            'status' => true,
            'data' => $penjualan]
            , REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
        }
        else {
            $this->response([
                'status' => false,
                'message' => 'No data/id not found'
            ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
        }
    } 

    //hapus data penjualan berdasarkan kode penjualan
    public function hapusDataPenjualan_delete() 
    {
        $id = $this->delete('penjualan_kode');

        if ($id === null){
            $this->response([
                'status' => false,
                'message' => 'Provide on id'
            ], REST_Controller::HTTP_BAD_REQUEST); // NOT_FOUND (404) being the HTTP response code
        }
        else {
            if ($this->barang->deleteDataPenjualan($id) > 0){
                //ok
                $this->response([
                    'status' => true,
                    'penjualan_kode' => $id,
                    'message' => 'id deleted']
                    , REST_Controller::HTTP_NO_CONTENT); // NO_CONTENT (204) being the HTTP response code
            }
            else {
                //not found
                $this->response([
                    'status' => false,
                    'message' => 'id not found'
                ], REST_Controller::HTTP_BAD_REQUEST); // NOT_FOUND (404) being the HTTP response code
            }
        }
    }

    //untuk membuat kode penjualan transaksi
    public function penjualankode_post() 
    {
        $time =mt_rand(1, time());
        $no = date('dmy' . $time);
        $nomor =array('penjualan_kode' => $no);

        $this->response( [
            'status' => true,
            'penjualan_kode' => $nomor,
            'message' => 'new penjualan kode has been created']
            , REST_Controller::HTTP_CREATED); // CREATED (201) being the HTTP response code
    }

    //untuk menyimpan data penjualan pada tabel t_penjualan
    public function simpanpenjualan_post()
    {
        $data = [
            'penjualan_kode' => $this->post('penjualan_kode'),
            'penjualan_nama_pembeli' => $this->post('penjualan_nama_pembeli'),
            'penjualan_no_hp_pembeli' => $this->post('penjualan_no_hp_pembeli'),
            'penjualan_tanggal' => $this->post('penjualan_tanggal')
        ];

        if ($this->barang->createPenjualan($data) > 0) {
            $this->response([
                'status' => true,
                'message' => 'new data penjualan has been created']
                , REST_Controller::HTTP_CREATED); // CREATED (201) being the HTTP response code
        }
        else {
              $this->response([
                'status' => false,
                'message' => 'fail to create new data penjualan'
            ], REST_Controller::HTTP_BAD_REQUEST); // NOT_FOUND (404) being the HTTP response code
        }
    }


    //untuk menyimpan data penjualan pada tabel t_penjualan_detail
    public function simpanpenjualandetail_post()
    {
        $id = $this->post('barang_id');
        $getBarang = $this->db->select('barang_harga')
                                ->from('m_barang')
                                ->where ('barang_id', $id)
                                ->get()->result_array();
        $data = [ 
            'penjualan_id' => $this->post('penjualan_id'),
            'barang_id' => $this->post('barang_id'),
            'penjualan_kode' => $this->post('penjualan_kode'),
            'jumlah_detail' => $this->post('jumlah_detail'),
            'total_detail' => $this->post('jumlah_detail') * $getBarang[0]['barang_harga']                                                                  
        ];

        if ($this->barang->createPenjualandetail($data) > 0) {
            $this->db->set(('barang_stok'),
                           ('barang_stok-') .$this->post('jumlah_detail'), false)
                     ->where('barang_id', $this->post('barang_id'))
                     ->update('m_barang');
            $this->response([
                'status' => true,
                'message' => 'new data penjualan detail has been created']
                , REST_Controller::HTTP_CREATED); // CREATED (201) being the HTTP response code
        }
        else {
              $this->response([
                'status' => false,
                'message' => 'fail to create new data penjualan detail'
            ], REST_Controller::HTTP_BAD_REQUEST); // NOT_FOUND (404) being the HTTP response code
        }
    }
}